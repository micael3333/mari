import crypto from 'crypto'

const API_URL = 'https://api.nowpayments.io/v1'

export type CreateInvoiceInput = {
  orderId: string
  orderDescription: string
  priceAmount: number
  priceCurrency: string
  successUrl: string
  cancelUrl: string
  ipnCallbackUrl: string
}

export async function createNowPaymentsInvoice(input: CreateInvoiceInput) {
  const apiKey = process.env.NOWPAYMENTS_API_KEY
  if (!apiKey) throw new Error('Missing NOWPAYMENTS_API_KEY')

  const res = await fetch(`${API_URL}/invoice`, {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      price_amount: input.priceAmount,
      price_currency: input.priceCurrency,
      order_id: input.orderId,
      order_description: input.orderDescription,
      success_url: input.successUrl,
      cancel_url: input.cancelUrl,
      ipn_callback_url: input.ipnCallbackUrl,
    }),
  })

  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(`NOWPayments invoice failed: ${JSON.stringify(data)}`)
  }
  return data as { invoice_url?: string; id?: string; order_id?: string }
}

function sortObject(obj: any): any {
  if (Array.isArray(obj)) return obj.map(sortObject)
  if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).sort().reduce((acc: any, key) => {
      acc[key] = sortObject(obj[key])
      return acc
    }, {})
  }
  return obj
}

export function verifyNowPaymentsSignature(rawBody: string, signature: string | null) {
  const secret = process.env.NOWPAYMENTS_IPN_SECRET
  if (!secret) throw new Error('Missing NOWPAYMENTS_IPN_SECRET')
  if (!signature) return false

  // NOWPayments IPN usually signs the sorted JSON body with HMAC SHA-512.
  // This supports both raw-body and sorted-json comparison to avoid simple formatting mismatch.
  let sortedBody = rawBody
  try { sortedBody = JSON.stringify(sortObject(JSON.parse(rawBody))) } catch {}

  const hmacRaw = crypto.createHmac('sha512', secret).update(rawBody).digest('hex')
  const hmacSorted = crypto.createHmac('sha512', secret).update(sortedBody).digest('hex')

  return timingSafeEqual(hmacRaw, signature) || timingSafeEqual(hmacSorted, signature)
}

function timingSafeEqual(a: string, b: string) {
  try {
    const A = Buffer.from(a)
    const B = Buffer.from(b)
    return A.length === B.length && crypto.timingSafeEqual(A, B)
  } catch { return false }
}
