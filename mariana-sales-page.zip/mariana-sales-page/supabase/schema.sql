create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  status text not null default 'pending',
  access_token text not null unique default encode(gen_random_bytes(24), 'hex'),
  nowpayments_invoice_id text,
  nowpayments_order_id text unique,
  price_amount numeric not null,
  price_currency text not null,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

alter table public.orders enable row level security;

-- This MVP uses the service role key server-side only. Do not expose it to the browser.
