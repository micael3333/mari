'use client'

import { useState } from 'react'
import { Lock, ShieldCheck, Sparkles } from 'lucide-react'

export default function Home() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function checkout() {
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Erro ao criar checkout')
      window.location.href = data.invoiceUrl
    } catch (e: any) {
      setError(e.message || 'Erro inesperado')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <section className="mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-5 py-12">
        <div className="mb-6 rounded-full border border-pink-400/30 bg-pink-500/10 px-4 py-2 text-sm text-pink-100">
          acesso privado • liberação automática após pagamento
        </div>

        <h1 className="max-w-3xl text-center text-4xl font-black tracking-tight md:text-6xl">
          Mariana deixou um vídeo privado bloqueado.
        </h1>
        <p className="mt-5 max-w-2xl text-center text-lg text-zinc-300">
          Entre no acesso privado. O conteúdo só libera depois da confirmação do pagamento.
        </p>

        <div className="mt-10 grid w-full gap-8 md:grid-cols-[1.1fr_.9fr]">
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-zinc-950 shadow-2xl">
            <video
              className="h-[520px] w-full object-cover opacity-60 blur-[1px]"
              src={process.env.NEXT_PUBLIC_TEASER_VIDEO_URL || 'https://www.w3schools.com/html/movie.mp4'}
              muted
              autoPlay
              loop
              playsInline
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/45 p-8 text-center">
              <div className="mb-5 rounded-full bg-white/10 p-5 backdrop-blur">
                <Lock className="h-10 w-10" />
              </div>
              <h2 className="text-3xl font-bold">Vídeo bloqueado</h2>
              <p className="mt-3 max-w-sm text-zinc-300">
                Após pagar, você recebe um link único para assistir o conteúdo completo.
              </p>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-zinc-950 p-6 shadow-2xl">
            <div className="flex items-center gap-3 text-pink-200">
              <Sparkles className="h-5 w-5" />
              <span className="text-sm font-semibold uppercase tracking-widest">acesso imediato</span>
            </div>
            <div className="mt-8">
              <p className="text-sm text-zinc-400">Hoje</p>
              <p className="text-5xl font-black">R$ 9,90</p>
              <p className="mt-3 text-zinc-400">Pagamento via NOWPayments. Você recebe o acesso assim que o pagamento for confirmado.</p>
            </div>

            <label className="mt-8 block text-sm font-medium text-zinc-300">Seu e-mail para receber o acesso</label>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@email.com"
              className="mt-2 w-full rounded-2xl border border-white/10 bg-black px-4 py-4 text-white outline-none ring-pink-500/30 focus:ring-4"
            />
            {error && <p className="mt-3 text-sm text-red-300">{error}</p>}
            <button
              onClick={checkout}
              disabled={loading || !email}
              className="mt-5 w-full rounded-2xl bg-pink-500 px-5 py-4 text-lg font-bold text-white transition hover:bg-pink-400 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? 'Criando checkout...' : 'Desbloquear vídeo'}
            </button>

            <div className="mt-6 flex items-start gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-green-300" />
              <p>O link é individual. Se o pagamento não for confirmado, o vídeo continua bloqueado.</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
