import { Lock, CheckCircle2 } from 'lucide-react'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

export default async function AccessPage({ params }: { params: { token: string } }) {
  const { data: order } = await supabaseAdmin
    .from('orders')
    .select('status, email, paid_at')
    .eq('access_token', params.token)
    .single()

  const paid = Boolean(order?.paid_at) || ['finished', 'confirmed', 'sending'].includes(String(order?.status || '').toLowerCase())
  const videoUrl = process.env.PRIVATE_VIDEO_URL || 'https://www.w3schools.com/html/mov_bbb.mp4'

  return (
    <main className="min-h-screen bg-black px-5 py-10 text-white">
      <div className="mx-auto max-w-4xl">
        <a href="/" className="text-sm text-zinc-400 hover:text-white">← voltar</a>
        <div className="mt-8 rounded-3xl border border-white/10 bg-zinc-950 p-6">
          {paid ? (
            <>
              <div className="mb-5 flex items-center gap-3 text-green-300"><CheckCircle2 /> Pagamento confirmado</div>
              <h1 className="mb-6 text-3xl font-black">Seu vídeo está liberado</h1>
              <video className="w-full rounded-2xl" src={videoUrl} controls playsInline controlsList="nodownload" />
            </>
          ) : (
            <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
              <div className="mb-5 rounded-full bg-white/10 p-5"><Lock className="h-10 w-10" /></div>
              <h1 className="text-3xl font-black">Pagamento ainda não confirmado</h1>
              <p className="mt-3 max-w-md text-zinc-300">Quando a NOWPayments confirmar o pagamento, atualize esta página e o vídeo será liberado automaticamente.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
