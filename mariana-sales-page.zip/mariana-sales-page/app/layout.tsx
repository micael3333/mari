import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Mariana | Acesso privado',
  description: 'Página de acesso privado com conteúdo bloqueado até confirmação do pagamento.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>
}
