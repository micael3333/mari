import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'
import { createNowPaymentsInvoice } from '@/lib/nowpayments'

function isEmail(v: string) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) }

export async function POST(req: Request) {
  try {
    const { email } = await req.json()
    if (!email || !isEmail(email)) {
      return NextResponse.json({ error: 'Digite um e-mail válido.' }, { status: 400 })
    }

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'
    const priceAmount = Number(process.env.PRICE_AMOUNT || '9.90')
    const priceCurrency = process.env.PRICE_CURRENCY || 'brl'
    const productName = process.env.PRODUCT_NAME || 'Acesso privado Mariana'

    const { data: order, error } = await supabaseAdmin
      .from('orders')
      .insert({
        email,
        price_amount: priceAmount,
        price_currency: priceCurrency,
        status: 'pending',
      })
      .select('id, access_token')
      .single()

    if (error || !order) throw error || new Error('Order not created')

    const invoice = await createNowPaymentsInvoice({
      orderId: order.id,
      orderDescription: productName,
      priceAmount,
      priceCurrency,
      successUrl: `${siteUrl}/access/${order.access_token}`,
      cancelUrl: `${siteUrl}/`,
      ipnCallbackUrl: `${siteUrl}/api/nowpayments/ipn`,
    })

    await supabaseAdmin
      .from('orders')
      .update({
        nowpayments_invoice_id: invoice.id ? String(invoice.id) : null,
        nowpayments_order_id: order.id,
      })
      .eq('id', order.id)

    if (!invoice.invoice_url) throw new Error('NOWPayments did not return invoice_url')

    return NextResponse.json({ invoiceUrl: invoice.invoice_url })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro ao criar checkout.' }, { status: 500 })
  }
}
