import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'
import { verifyNowPaymentsSignature } from '@/lib/nowpayments'

const PAID_STATUSES = new Set(['finished', 'confirmed', 'sending'])

export async function POST(req: Request) {
  const raw = await req.text()
  const sig = req.headers.get('x-nowpayments-sig')

  try {
    const valid = verifyNowPaymentsSignature(raw, sig)
    if (!valid) return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })

    const payload = JSON.parse(raw)
    const orderId = payload.order_id
    const status = String(payload.payment_status || '').toLowerCase()

    if (!orderId) return NextResponse.json({ error: 'Missing order_id' }, { status: 400 })

    const update: Record<string, any> = { status }
    if (PAID_STATUSES.has(status)) update.paid_at = new Date().toISOString()

    const { error } = await supabaseAdmin
      .from('orders')
      .update(update)
      .eq('id', orderId)

    if (error) throw error
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'IPN error' }, { status: 500 })
  }
}
