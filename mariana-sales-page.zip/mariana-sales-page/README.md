# Mariana Sales Page — MVP

Página de vendas com vídeo bloqueado até pagamento confirmado pela NOWPayments.

## O que entrega

- Landing page com teaser/vídeo borrado e botão de compra.
- Checkout via NOWPayments Invoice.
- Webhook/IPN para confirmar pagamento.
- Link único de acesso `/access/[token]`.
- Vídeo privado liberado somente quando `paid_at` for preenchido no Supabase.

## Setup rápido

1. Crie um projeto no Supabase.
2. Rode o SQL em `supabase/schema.sql` no SQL Editor.
3. Copie `.env.example` para `.env.local` e preencha:

```env
NEXT_PUBLIC_SITE_URL=https://seu-dominio.com
NEXT_PUBLIC_SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
NOWPAYMENTS_API_KEY=...
NOWPAYMENTS_IPN_SECRET=...
PRICE_AMOUNT=9.90
PRICE_CURRENCY=brl
PAY_CURRENCY=usdttrc20
PRIVATE_VIDEO_URL=https://...
NEXT_PUBLIC_TEASER_VIDEO_URL=https://...
```

4. Instale e rode:

```bash
npm install
npm run dev
```

5. Deploy na Vercel.
6. No painel da NOWPayments, configure o IPN Secret igual ao `.env` e use a URL pública:

```text
https://seu-dominio.com/api/nowpayments/ipn
```

## Observações importantes

- `SUPABASE_SERVICE_ROLE_KEY` fica somente no servidor. Nunca coloque no front.
- Para produção, use vídeo em storage privado/signed URLs. `PRIVATE_VIDEO_URL` público é MVP.
- Se quiser Pix/cartão com baixa fricção no Brasil, NOWPayments pode não ser ideal. Para conversão brasileira, Mercado Pago/Asaas/Pagar.me geralmente são melhores.
- NOWPayments pode exigir cripto/on-ramp dependendo do fluxo. Teste antes de rodar tráfego.

## Ajustes rápidos de copy

Headline da página fica em `app/page.tsx`.
Preço fica em `.env.local`.
Vídeo privado fica em `PRIVATE_VIDEO_URL`.
Teaser borrado fica em `NEXT_PUBLIC_TEASER_VIDEO_URL`.
